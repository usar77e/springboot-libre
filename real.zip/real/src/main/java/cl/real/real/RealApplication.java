package cl.real.real;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealApplication.class, args);
	}

}
